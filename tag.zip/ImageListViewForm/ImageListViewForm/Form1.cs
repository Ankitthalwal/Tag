﻿using Manina.Windows.Forms;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace ImageListViewForm
{
    public partial class Form1 : Form
    {
        private ImageListView imageListView;

        public Form1()
        {
            InitializeComponent();
            imageListView = new ImageListView
            {
                Dock = DockStyle.Fill,
                View = Manina.Windows.Forms.View.Thumbnails  // Display images as thumbnails
            };

            // Set custom renderer
            imageListView.SetRenderer(new CustomImageRenderer());

            // Add ImageListView to the form
            this.Controls.Add(imageListView);
        }

        public class CustomImageRenderer : ImageListView.ImageListViewRenderer
        {
            public override void DrawItem(Graphics g, ImageListViewItem item, ItemState state, Rectangle bounds)
            {
                // Draw the image thumbnail
                Image img = item.GetCachedImage(CachedImageType.Thumbnail);
                if (img != null)
                {
                    g.DrawImage(img, bounds);
                }

                // Get author information from the item's Tag property
                string authorText = item.Artist?.ToString() ?? "Unknown Author";
               

                // Set font and color for the text
                Font font = new Font("Arial", 10, FontStyle.Bold);
                Brush brush = new SolidBrush(Color.Red);

                // Calculate the position to draw the text (on the bottom of the image)
                int textYPosition = bounds.Bottom - 50;  // Adjust this to place the text above the bottom
                PointF textPosition = new PointF(bounds.Left + 15, textYPosition);

                // Draw the text over the image
                g.DrawString(authorText, font, brush, textPosition);
            }
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Multiselect = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    foreach (string filename in openFileDialog.FileNames)
                    {
                        // Create an item and set the Tag property to the author's name
                        ImageListViewItem item = new ImageListViewItem(filename)
                    {
                        Tag = "Author: " + System.IO.Path.GetFileNameWithoutExtension(filename)  // Example author name
                    };
                    imageListView.Items.Add(item);
                    }
                }
            }
        }
    }
}
